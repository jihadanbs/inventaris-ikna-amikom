 <!-- footer section -->
 <section class="container-fluid footer_section">
     <div class="container">
         <p>
             &copy; <span id="displayYear"></span> Situs IKNAventory Isi Konten Dilindungi Oleh
             <a href="https://www.instagram.com/ikna_jogja/?hl=en" target="_blank"> IKNA AMIKOM Yogyakarta</a>
         </p>
     </div>
 </section>
 <!-- footer section -->