 <!-- contact section -->
 <section class="contact_section layout_padding" id="contactLink">
     <div class="container">
         <div class="heading_container">
             <h2>
                 Feedback Pengunjung
             </h2>
         </div>
     </div>
     <div class="container">
         <div class="row">
             <div class="col-lg-6 col-md-8 mx-auto">
                 <form>
                     <div class="form-row">
                         <div class="form-group col-md-6">
                             <input type="text" class="form-control" id="inputName4" placeholder="Nama Lengkap">
                         </div>
                         <div class="form-group col-md-6">
                             <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
                         </div>

                     </div>
                     <div class="form-row">
                         <div class="form-group col">
                             <input type="text" class="form-control" id="inputSubject4" placeholder="Subjek">
                         </div>
                     </div>
                     <div class="form-group">
                         <input type="text" class="form-control" id="inputMessage" placeholder="Pesan">
                     </div>
                     <div class="d-flex justify-content-center">
                         <button type="submit" class="">Send</button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </section>
 <!-- end contact section -->