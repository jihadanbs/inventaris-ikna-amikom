<script type="text/javascript" src="<?= base_url('assets/js/jquery-3.4.1.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('assets/js/custom.js'); ?>"></script>